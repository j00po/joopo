---
name: tar-hook
description: tar-hook
metadata: {"joopo":{"events":["command:new"]}}
---

# Hook