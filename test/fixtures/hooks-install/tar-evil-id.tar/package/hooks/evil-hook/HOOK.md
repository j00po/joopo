---
name: evil-hook
description: evil-hook
metadata: {"joopo":{"events":["command:new"]}}
---

# Hook