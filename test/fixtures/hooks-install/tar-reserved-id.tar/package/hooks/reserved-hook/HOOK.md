---
name: reserved-hook
description: reserved-hook
metadata: {"joopo":{"events":["command:new"]}}
---

# Hook